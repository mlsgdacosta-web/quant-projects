# Mechanism Design Optimization Solver

Numerical solvers for simple mechanism-design and nonlinear pricing problems.

## Example
See `solvers/grid_search.py` for a grid-search approach to pricing under capacity constraints.
