# Time-Series Forecasting (ARIMA & GARCH)

Lightweight implementations and wrappers for ARIMA-style and GARCH-style models.
For production-quality models, install and use statsmodels and arch packages.
