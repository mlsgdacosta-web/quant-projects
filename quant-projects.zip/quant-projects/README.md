Quant Projects Bundle for Malu Sena Gomes da Costa

This archive contains five projects:
- monte-carlo-simulations
- market-maker-sim
- mechanism-design-optimization
- time-series-forecasting
- probability-problems

Each project has a README and basic code modules to get you started.
