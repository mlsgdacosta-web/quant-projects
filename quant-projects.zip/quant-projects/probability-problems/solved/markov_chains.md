# Markov Chains - Example Problem

**Problem:** Consider a two-state Markov chain with transition matrix...
**Solution:** (text explanation) and a short simulation in Python.
