# Market Maker Simulation with Limit Order Book (LOB)

Event-driven LOB simulator and simple inventory-based market-making strategy.

## Usage
Run `market_maker/simulator.py` to see a simple simulation example.
